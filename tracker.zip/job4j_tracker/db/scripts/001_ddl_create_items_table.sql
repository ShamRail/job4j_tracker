create table items (
   id serial primary key not null,
   name text
);