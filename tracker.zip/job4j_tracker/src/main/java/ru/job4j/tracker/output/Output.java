package ru.job4j.tracker.output;

public interface Output {
    void println(Object obj);
}
